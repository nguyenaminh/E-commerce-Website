package com.example.PhoneSellingWebsite.controller;

import com.example.PhoneSellingWebsite.model.Phone;
import com.example.PhoneSellingWebsite.model.dto.PhoneDTO;
import com.example.PhoneSellingWebsite.repository.PhoneRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;


@RestController
@RequestMapping("/phone")
@CrossOrigin(origins = "http://localhost:5173")
public class PhoneController {

    @Autowired
    private PhoneRepository phoneRepository;

    @PostMapping("/add")
    public ResponseEntity<Phone> addPhone(@RequestBody PhoneDTO phoneDTO) {

        Phone phone = new Phone();
        phone.setPhoneName(phoneDTO.getPhoneName());
        phone.setPrice(phoneDTO.getPrice());
        phone.setDescription(phoneDTO.getDescription());
        phone.setImage(phoneDTO.getImage());
        phone.setCreatedAt(LocalDateTime.now());
        phone.setCategory(phoneDTO.getCategory());
        phone.setBrand(phoneDTO.getBrand());

        Phone savedPhone = phoneRepository.save(phone);
        return ResponseEntity.ok(savedPhone);
    }

    @PutMapping("/edit/{id}")
    public ResponseEntity<Phone> editPhone(@PathVariable Integer id, @RequestBody PhoneDTO phoneDTO) {
        Optional<Phone> phoneOptional = phoneRepository.findById(id);
        if (phoneOptional.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        Phone phone = phoneOptional.get();
        phone.setPhoneName(phoneDTO.getPhoneName());
        phone.setPrice(phoneDTO.getPrice());
        phone.setDescription(phoneDTO.getDescription());
        phone.setImage(phoneDTO.getImage());
        phone.setCategory(phoneDTO.getCategory());
        phone.setBrand(phoneDTO.getBrand());

        Phone updatedPhone = phoneRepository.save(phone);
        return ResponseEntity.ok(updatedPhone);
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> deletePhone(@PathVariable Integer id) {
        if (!phoneRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }

        phoneRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/all")
    public ResponseEntity<List<Phone>> getAllPhones() {
        List<Phone> phones = phoneRepository.findAll();
        return ResponseEntity.ok(phones);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Phone> getPhoneById(@PathVariable Integer id) {
        Optional<Phone> phone = phoneRepository.findById(id);
        return phone.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping("/search")
    public ResponseEntity<List<Phone>> searchPhonesByName(@RequestParam String name) {
        List<Phone> phones = phoneRepository.searchByName(name);
        return ResponseEntity.ok(phones);
    }

}
