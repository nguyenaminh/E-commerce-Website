package com.example.PhoneSellingWebsite.model.dto;


import com.example.PhoneSellingWebsite.model.Phone;
import com.example.PhoneSellingWebsite.model.User;

import java.time.LocalDateTime;

public class CartDTO {

    private Integer cartId;

    private Double quantity;


    private Double price;

    private LocalDateTime createdAt;

    private Phone phone;

    private User user;



    public Integer getCartId() {
        return cartId;
    }

    public void setCartId(Integer cartId) {
        this.cartId = cartId;
    }

    public Double getQuantity() {
        return quantity;
    }

    public void setQuantity(Double quantity) {
        this.quantity = quantity;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }


    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public Phone getPhone() {
        return phone;
    }

    public void setPhone(Phone phone) {
        this.phone = phone;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}
