package com.example.PhoneSellingWebsite.controller;

import com.example.PhoneSellingWebsite.model.Order;
import com.example.PhoneSellingWebsite.model.Phone;
import com.example.PhoneSellingWebsite.model.dto.OrderDTO;
import com.example.PhoneSellingWebsite.repository.OrderRepository;
import com.example.PhoneSellingWebsite.repository.PhoneRepository;
import com.example.PhoneSellingWebsite.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import com.example.PhoneSellingWebsite.model.User;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/order")
@CrossOrigin(origins = "http://localhost:5173")
public class OrderController {
    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private PhoneRepository phoneRepository;

    @Autowired
    private UserService userService;

    @PostMapping
    public ResponseEntity<?> addOrder(@RequestBody OrderDTO orderDTO) {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            if (authentication == null || !authentication.isAuthenticated()) {
                return ResponseEntity.status(401).body("User not authenticated");
            }

            Integer userId = userService.getCurrentUserId(authentication);

            Phone phone = phoneRepository.findById(orderDTO.getPhone().getPhoneId())
                    .orElseThrow(() -> new Exception("Phone not found"));

            // Check if phone has enough quantity
            if (phone.getQuantity() < orderDTO.getQuantity()) {
                return ResponseEntity.status(400).body("Not enough phone quantity available");
            }

            Double totalPrice = phone.getPrice() * orderDTO.getQuantity();

            phone.setQuantity((int) (phone.getQuantity() - orderDTO.getQuantity()));
            phoneRepository.save(phone);

            Order order = new Order();
            order.setQuantity(orderDTO.getQuantity());
            order.setPrice(totalPrice);
            order.setCreatedAt(LocalDateTime.now());
            order.setPhone(phone);
            order.setPayment(orderDTO.getPayment());

            User user = new User();
            user.setUserId(userId);
            order.setUser(user);

            Order savedOrder = orderRepository.save(order);
            return ResponseEntity.ok(savedOrder);
        } catch (Exception e) {
            return ResponseEntity.status(400).body("Error adding order: " + e.getMessage());
        }
    }

    @PutMapping("/{orderId}")
    public ResponseEntity<?> editOrder(@PathVariable Integer orderId, @RequestBody OrderDTO orderDTO) {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            if (authentication == null || !authentication.isAuthenticated()) {
                return ResponseEntity.status(401).body("User not authenticated");
            }

            Integer userId = userService.getCurrentUserId(authentication);

            Order order = orderRepository.findById(orderId)
                    .orElseThrow(() -> new Exception("Order not found"));

            if (!order.getUser().getUserId().equals(userId)) {
                return ResponseEntity.status(403).body("You can only edit your own orders");
            }

            Phone phone = order.getPhone();
            int quantityDifference = 0;

            if (orderDTO.getQuantity() != null && !orderDTO.getQuantity().equals(order.getQuantity())) {
                quantityDifference = (int) (orderDTO.getQuantity() - order.getQuantity());

                // Check if phone has enough quantity if increasing order
                if (quantityDifference > 0 && phone.getQuantity() < quantityDifference) {
                    return ResponseEntity.status(400).body("Not enough phone quantity available");
                }
            }

            if (orderDTO.getPhone() != null && !orderDTO.getPhone().getPhoneId().equals(phone.getPhoneId())) {
                Phone newPhone = phoneRepository.findById(orderDTO.getPhone().getPhoneId())
                        .orElseThrow(() -> new Exception("New phone not found"));

                if (newPhone.getQuantity() < orderDTO.getQuantity()) {
                    return ResponseEntity.status(400).body("Not enough quantity available for the new phone");
                }

                phone.setQuantity((int) (phone.getQuantity() + order.getQuantity()));
                phoneRepository.save(phone);

                newPhone.setQuantity((int) (newPhone.getQuantity() - orderDTO.getQuantity()));
                phoneRepository.save(newPhone);

                phone = newPhone;
                order.setPhone(phone);
            } else if (quantityDifference != 0) {
                // Just quantity change, no phone change
                phone.setQuantity(phone.getQuantity() - quantityDifference);
                phoneRepository.save(phone);
            }

            if (orderDTO.getQuantity() != null) {
                order.setQuantity(orderDTO.getQuantity());
                Double totalPrice = phone.getPrice() * orderDTO.getQuantity();
                order.setPrice(totalPrice);
            }

            if (orderDTO.getPayment() != null) {
                order.setPayment(orderDTO.getPayment());
            }

            Order updatedOrder = orderRepository.save(order);
            return ResponseEntity.ok(updatedOrder);
        } catch (Exception e) {
            return ResponseEntity.status(400).body("Error editing order: " + e.getMessage());
        }
    }

    @DeleteMapping("/{orderId}")
    public ResponseEntity<?> deleteOrder(@PathVariable Integer orderId) {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            if (authentication == null || !authentication.isAuthenticated()) {
                return ResponseEntity.status(401).body("User not authenticated");
            }

            Integer userId = userService.getCurrentUserId(authentication);

            Order order = orderRepository.findById(orderId)
                    .orElseThrow(() -> new Exception("Order not found"));

            if (!order.getUser().getUserId().equals(userId)) {
                return ResponseEntity.status(403).body("You can only delete your own orders");
            }

            // Return the quantity to the phone
            Phone phone = order.getPhone();
            phone.setQuantity((int) (phone.getQuantity() + order.getQuantity()));
            phoneRepository.save(phone);

            orderRepository.delete(order);
            return ResponseEntity.ok("Order deleted successfully");
        } catch (Exception e) {
            return ResponseEntity.status(400).body("Error deleting order: " + e.getMessage());
        }
    }

    @GetMapping("/all-order")
    public ResponseEntity<?> showAllOrders() {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            if (authentication == null || !authentication.isAuthenticated()) {
                return ResponseEntity.status(401).body("User not authenticated");
            }

            List<Order> myOrders = orderRepository.findAll();

            return ResponseEntity.ok(myOrders);
        } catch (Exception e) {
            return ResponseEntity.status(400).body("Error retrieving orders: " + e.getMessage());
        }
    }

    @GetMapping("/my-orders")
    public ResponseEntity<?> showMyOrders() {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            if (authentication == null || !authentication.isAuthenticated()) {
                return ResponseEntity.status(401).body("User not authenticated");
            }

            Integer userId = userService.getCurrentUserId(authentication);

            List<Order> myOrders = orderRepository.findAll().stream()
                    .filter(order -> order.getUser().getUserId().equals(userId))
                    .collect(Collectors.toList());

            return ResponseEntity.ok(myOrders);
        } catch (Exception e) {
            return ResponseEntity.status(400).body("Error retrieving orders: " + e.getMessage());
        }
    }
}
