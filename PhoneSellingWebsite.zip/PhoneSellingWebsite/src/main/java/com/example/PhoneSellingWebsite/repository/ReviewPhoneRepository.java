package com.example.PhoneSellingWebsite.repository;

import com.example.PhoneSellingWebsite.model.ReviewPhone;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface ReviewPhoneRepository extends JpaRepository<ReviewPhone, Integer> {
    Optional<ReviewPhone> findByUserUserIdAndPhonePhoneId(Integer userId, Integer phoneId);
    List<ReviewPhone> findByPhonePhoneId(Integer phoneId);

}
