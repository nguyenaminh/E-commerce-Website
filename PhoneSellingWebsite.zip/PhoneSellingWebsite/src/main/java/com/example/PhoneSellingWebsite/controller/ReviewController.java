package com.example.PhoneSellingWebsite.controller;

import com.example.PhoneSellingWebsite.model.ReviewPhone;
import com.example.PhoneSellingWebsite.model.dto.ReviewPhoneDTO;
import com.example.PhoneSellingWebsite.model.User;
import com.example.PhoneSellingWebsite.repository.PhoneRepository;
import com.example.PhoneSellingWebsite.repository.ReviewPhoneRepository;
import com.example.PhoneSellingWebsite.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/review")
@CrossOrigin(origins = "http://localhost:5173")
public class ReviewController {

    @Autowired
    private ReviewPhoneRepository reviewPhoneRepository;

    @Autowired
    private UserService userService;

    @Autowired
    private PhoneRepository phoneRepository;

    @GetMapping("/phone/{phoneId}")
    public ResponseEntity<?> getReviewsByPhoneId(@PathVariable Integer phoneId) {
        try {
            List<ReviewPhone> reviews = reviewPhoneRepository.findByPhonePhoneId(phoneId);
            if (reviews.isEmpty()) {
                return ResponseEntity.status(404).body("No reviews found for this phone");
            }
            return ResponseEntity.ok(reviews);
        } catch (Exception e) {
            return ResponseEntity.status(400).body("Error: " + e.getMessage());
        }
    }

    @PostMapping("/add")
    public ResponseEntity<?> addReview(@RequestBody ReviewPhoneDTO reviewPhoneDTO) {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            if (authentication == null || !authentication.isAuthenticated()) {
                return ResponseEntity.status(401).body("User not authenticated");
            }

            Integer userId = userService.getCurrentUserId(authentication);

            // Check if user has already reviewed this phone
            boolean alreadyReviewed = reviewPhoneRepository
                    .findByUserUserIdAndPhonePhoneId(userId, reviewPhoneDTO.getPhone().getPhoneId())
                    .isPresent();

            if (alreadyReviewed) {
                return ResponseEntity.status(400).body("You have already reviewed this phone");
            }

            ReviewPhone review = new ReviewPhone();
            review.setRating(reviewPhoneDTO.getRating());
            review.setComment(reviewPhoneDTO.getComment());
            review.setCreatedAt(LocalDateTime.now());
            review.setModifiedAt(LocalDateTime.now());

            User user = new User();
            user.setUserId(userId);
            review.setUser(user);

            review.setPhone(reviewPhoneDTO.getPhone());

            ReviewPhone savedReview = reviewPhoneRepository.save(review);
            return ResponseEntity.ok(savedReview);
        } catch (Exception e) {
            return ResponseEntity.status(400).body("Error adding review: " + e.getMessage());
        }
    }

    @GetMapping("/{reviewId}")
    public ResponseEntity<?> getReview(@PathVariable Integer reviewId) {
        try {
            ReviewPhone review = reviewPhoneRepository.findById(reviewId)
                    .orElseThrow(() -> new Exception("Review not found"));
            return ResponseEntity.ok(review);
        } catch (Exception e) {
            return ResponseEntity.status(404).body("Error: " + e.getMessage());
        }
    }


    @PutMapping("/update/{reviewId}")
    public ResponseEntity<?> updateReview(@PathVariable Integer reviewId,
                                          @RequestBody ReviewPhoneDTO reviewPhoneDTO) {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            if (authentication == null || !authentication.isAuthenticated()) {
                return ResponseEntity.status(401).body("User not authenticated");
            }

            Integer currentUserId = userService.getCurrentUserId(authentication);
            ReviewPhone review = reviewPhoneRepository.findById(reviewId)
                    .orElseThrow(() -> new Exception("Review not found"));

            // Check if the current user is the owner of the review
            if (!review.getUser().getUserId().equals(currentUserId)) {
                return ResponseEntity.status(403).body("You can only update your own reviews");
            }

            // Update only allowed fields
            if (reviewPhoneDTO.getRating() != null) {
                review.setRating(reviewPhoneDTO.getRating());
            }
            if (reviewPhoneDTO.getComment() != null) {
                review.setComment(reviewPhoneDTO.getComment());
            }
            review.setModifiedAt(LocalDateTime.now());

            ReviewPhone updatedReview = reviewPhoneRepository.save(review);
            return ResponseEntity.ok(updatedReview);
        } catch (Exception e) {
            return ResponseEntity.status(400).body("Error updating review: " + e.getMessage());
        }
    }

    @DeleteMapping("/delete/{reviewId}")
    public ResponseEntity<?> deleteReview(@PathVariable Integer reviewId) {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            if (authentication == null || !authentication.isAuthenticated()) {
                return ResponseEntity.status(401).body("User not authenticated");
            }

            Integer currentUserId = userService.getCurrentUserId(authentication);
            ReviewPhone review = reviewPhoneRepository.findById(reviewId)
                    .orElseThrow(() -> new Exception("Review not found"));

            // Check if the current user is the owner of the review
            if (!review.getUser().getUserId().equals(currentUserId)) {
                return ResponseEntity.status(403).body("You can only delete your own reviews");
            }

            reviewPhoneRepository.delete(review);
            return ResponseEntity.ok("Review deleted successfully");
        } catch (Exception e) {
            return ResponseEntity.status(400).body("Error deleting review: " + e.getMessage());
        }
    }
}
