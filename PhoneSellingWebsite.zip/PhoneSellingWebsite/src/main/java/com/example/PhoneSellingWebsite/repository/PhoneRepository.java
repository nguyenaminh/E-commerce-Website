package com.example.PhoneSellingWebsite.repository;

import com.example.PhoneSellingWebsite.model.Phone;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface PhoneRepository extends JpaRepository<Phone, Integer> {
    @Query("SELECT p FROM Phone p WHERE p.phoneId = :phoneId")
    Phone findPhoneById(@Param("phoneId") Integer phoneId);

    @Query("SELECT p FROM Phone p WHERE LOWER(p.phoneName) LIKE LOWER(CONCAT('%', :name, '%'))")
    List<Phone> searchByName(@Param("name") String name);
}
