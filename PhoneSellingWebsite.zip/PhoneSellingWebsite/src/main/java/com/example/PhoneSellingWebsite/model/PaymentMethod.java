package com.example.PhoneSellingWebsite.model;

public enum PaymentMethod {
    COD;

    PaymentMethod() {
    }
}