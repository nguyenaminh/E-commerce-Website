package com.example.PhoneSellingWebsite.service;

import com.example.PhoneSellingWebsite.model.dto.UserDTO;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;

public interface UserService extends UserDetailsService  {

    UserDetails authenticate(UserDTO userDTO);

    Integer getCurrentUserId(Authentication authentication);

}
