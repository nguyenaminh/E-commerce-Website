package com.example.PhoneSellingWebsite.model;

import jakarta.persistence.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "review_products")
public class ReviewPhone {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer reviewProductId;

    private Integer rating;
    private String comment;
    private LocalDateTime createdAt;
    private LocalDateTime modifiedAt;

    @ManyToOne()
    @JoinColumn(name = "phone_id")
    private Phone phone;

    @ManyToOne()
    @JoinColumn(name = "user_id")
    private User user;

    // Constructors, getters, setters

    public ReviewPhone() {
    }

    public Integer getReviewProductId() {
        return reviewProductId;
    }

    public void setReviewProductId(Integer reviewProductId) {
        this.reviewProductId = reviewProductId;
    }

    public Integer getRating() {
        return rating;
    }

    public void setRating(Integer rating) {
        this.rating = rating;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getModifiedAt() {
        return modifiedAt;
    }

    public void setModifiedAt(LocalDateTime modifiedAt) {
        this.modifiedAt = modifiedAt;
    }

    public Phone getPhone() {
        return phone;
    }

    public void setPhone(Phone phone) {
        this.phone = phone;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}