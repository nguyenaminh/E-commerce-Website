package com.example.PhoneSellingWebsite.model;

public enum Role {
    ADMIN, USER;

    Role() {
    }
}
