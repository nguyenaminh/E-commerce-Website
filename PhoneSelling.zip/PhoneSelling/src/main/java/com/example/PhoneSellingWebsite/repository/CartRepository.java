package com.example.PhoneSellingWebsite.repository;

import com.example.PhoneSellingWebsite.model.Cart;
import com.example.PhoneSellingWebsite.model.Phone;
import com.example.PhoneSellingWebsite.model.User;
import org.springframework.data.jpa.repository.JpaRepository;


import java.util.List;

public interface CartRepository extends JpaRepository<Cart, Integer> {
    
    void deleteAllByUser(User user);

    List<Cart> findByUser(User user);

    Cart findByUserAndPhone(User user, Phone phone);
}
