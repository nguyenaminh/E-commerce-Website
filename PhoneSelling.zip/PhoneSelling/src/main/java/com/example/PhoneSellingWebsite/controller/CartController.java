package com.example.PhoneSellingWebsite.controller;

import com.example.PhoneSellingWebsite.model.Cart;
import com.example.PhoneSellingWebsite.model.Order;
import com.example.PhoneSellingWebsite.model.dto.CartDTO;
import com.example.PhoneSellingWebsite.model.Phone;
import com.example.PhoneSellingWebsite.model.User;
import com.example.PhoneSellingWebsite.repository.CartRepository;
import com.example.PhoneSellingWebsite.repository.OrderRepository;
import com.example.PhoneSellingWebsite.repository.PhoneRepository;
import com.example.PhoneSellingWebsite.repository.UserRepository;
import com.example.PhoneSellingWebsite.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/cart")
@CrossOrigin(origins = "http://localhost:5173")
public class CartController {

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private PhoneRepository phoneRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private UserService userService;

    @Autowired
    private OrderRepository orderRepository;

    @GetMapping
    public ResponseEntity<?> getCartItems() {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            Integer currentUserId = userService.getCurrentUserId(authentication);


            User user = userRepository.findById(currentUserId)
                    .orElseThrow(() -> new RuntimeException("User not found"));

            List<Cart> cartItems = cartRepository.findByUser(user);
            return ResponseEntity.ok(cartItems);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(e.getMessage());
        }
    }

    @PostMapping
    public ResponseEntity<?> addToCart(@RequestBody CartDTO cartDTO) {
        try {
            if (cartDTO == null || cartDTO.getPhone() == null || cartDTO.getPhone().getPhoneId() == null) {
                return ResponseEntity.badRequest().body("Invalid cart data: Phone ID is required");
            }

            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            Integer currentUserId = userService.getCurrentUserId(authentication);

            System.out.println("Cart User ID: " + currentUserId);


            User user = userRepository.findById(currentUserId)
                    .orElseThrow(() -> new RuntimeException("User not found"));

            Phone phone = phoneRepository.findById(cartDTO.getPhone().getPhoneId())
                    .orElseThrow(() -> new RuntimeException("Phone not found"));

            Cart existingItem = cartRepository.findByUserAndPhone(user, phone);

            if (existingItem != null) {
                existingItem.setQuantity(existingItem.getQuantity() + cartDTO.getQuantity());
                existingItem.setPrice(phone.getPrice() * existingItem.getQuantity());
                Cart updatedItem = cartRepository.save(existingItem);
                return ResponseEntity.ok(updatedItem);
            } else {
                Cart newItem = new Cart();
                newItem.setUser(user);
                newItem.setPhone(phone);
                newItem.setQuantity(cartDTO.getQuantity());
                newItem.setPrice(phone.getPrice() * cartDTO.getQuantity());
                newItem.setCreatedAt(LocalDateTime.now());
                Cart savedItem = cartRepository.save(newItem);
                return ResponseEntity.ok(savedItem);
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
    }

    @PutMapping("/{cartId}")
    public ResponseEntity<?> updateCartItem(
            @PathVariable Integer cartId,
            @RequestBody CartDTO cartDTO) {
        try {
            if (cartId == null) {
                return ResponseEntity.badRequest().body("Cart ID must not be null");
            }
            if (cartDTO == null || cartDTO.getQuantity() == null) {
                return ResponseEntity.badRequest().body("Invalid cart data: Quantity is required");
            }

            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            Integer currentUserId = userService.getCurrentUserId(authentication);

            Cart cartItem = cartRepository.findById(cartId)
                    .orElseThrow(() -> new RuntimeException("Cart item not found"));

            if (!cartItem.getUser().getUserId().equals(currentUserId)) {
                throw new RuntimeException("Unauthorized cart update");
            }

            cartItem.setQuantity(cartDTO.getQuantity());
            cartItem.setPrice(cartItem.getPhone().getPrice() * cartDTO.getQuantity());
            Cart updatedItem = cartRepository.save(cartItem);
            return ResponseEntity.ok(updatedItem);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
    }

    @DeleteMapping("/{cartId}")
    public ResponseEntity<?> removeCartItem(@PathVariable Integer cartId) {
        try {
            if (cartId == null) {
                return ResponseEntity.badRequest().body("Cart ID must not be null");
            }

            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            Integer currentUserId = userService.getCurrentUserId(authentication);

            Cart cartItem = cartRepository.findById(cartId)
                    .orElseThrow(() -> new RuntimeException("Cart item not found"));

            if (!cartItem.getUser().getUserId().equals(currentUserId)) {
                throw new RuntimeException("Unauthorized cart deletion");
            }

            cartRepository.delete(cartItem);
            return ResponseEntity.ok("Delete success");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
    }

    @DeleteMapping
    public ResponseEntity<?> clearCart() {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            Integer currentUserId = userService.getCurrentUserId(authentication);

            User user = userRepository.findById(currentUserId)
                    .orElseThrow(() -> new RuntimeException("User not found"));

            cartRepository.deleteAllByUser(user);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(e.getMessage());
        }
    }

    @PostMapping("/checkout/{cartId}")
    public ResponseEntity<?> checkoutSingleCartItem(@PathVariable Integer cartId) {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            Integer currentUserId = userService.getCurrentUserId(authentication);

            User user = userRepository.findById(currentUserId)
                    .orElseThrow(() -> new RuntimeException("User not found"));

            Cart cartItem = cartRepository.findById(cartId)
                    .orElseThrow(() -> new RuntimeException("Cart item not found"));

            if (!cartItem.getUser().getUserId().equals(currentUserId)) {
                return ResponseEntity.status(HttpStatus.FORBIDDEN)
                        .body("Unauthorized checkout - cart item doesn't belong to user");
            }

            Phone phone = cartItem.getPhone();
            if (phone.getQuantity() < cartItem.getQuantity()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body("Not enough quantity available for phone: " + phone.getPhoneName());
            }

            Order order = new Order();
            order.setUser(user);
            order.setPhone(phone);
            order.setQuantity(cartItem.getQuantity());
            order.setPrice(cartItem.getPrice());
            order.setCreatedAt(LocalDateTime.now());

            Order savedOrder = orderRepository.save(order);

            phone.setQuantity((int) (phone.getQuantity() - cartItem.getQuantity()));
            phoneRepository.save(phone);

            cartRepository.delete(cartItem);

            return ResponseEntity.ok(savedOrder);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Error during checkout: " + e.getMessage());
        }
    }


}
