package com.example.PhoneSellingWebsite.repository;

import com.example.PhoneSellingWebsite.model.Phone;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface PhoneRepository extends JpaRepository<Phone, Integer> {
    @Query("SELECT p FROM Phone p WHERE p.phoneId = :phoneId")
    Phone findPhoneById(@Param("phoneId") Integer phoneId);
}
