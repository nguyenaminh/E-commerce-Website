package com.example.PhoneSellingWebsite;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PhoneSellingWebsiteApplication {

	public static void main(String[] args) {
		SpringApplication.run(PhoneSellingWebsiteApplication.class, args);
	}

}
