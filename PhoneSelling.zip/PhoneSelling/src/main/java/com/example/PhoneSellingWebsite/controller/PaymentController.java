package com.example.PhoneSellingWebsite.controller;

import com.example.PhoneSellingWebsite.model.Payment;
import com.example.PhoneSellingWebsite.model.dto.PaymentDTO;
import com.example.PhoneSellingWebsite.repository.PaymentRepository;
import com.example.PhoneSellingWebsite.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/payment")
@CrossOrigin(origins = "http://localhost:5173")
public class PaymentController {
    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private UserService userService;

    @PostMapping
    public ResponseEntity<?> createPayment(@RequestBody PaymentDTO paymentDTO) {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            if (authentication == null || !authentication.isAuthenticated()) {
                return ResponseEntity.status(401).body("User not authenticated");
            }

            Payment payment = new Payment();
            payment.setReceivedUser(paymentDTO.getReceivedUser());
            payment.setReceivedAddress(paymentDTO.getReceivedAddress());
            payment.setPhoneNumber(paymentDTO.getPhoneNumber());
            payment.setPaymentMethod(paymentDTO.getPaymentMethod());

            Payment savedPayment = paymentRepository.save(payment);
            return ResponseEntity.ok(savedPayment);
        } catch (Exception e) {
            return ResponseEntity.status(400).body("Error creating payment: " + e.getMessage());
        }
    }

    @PutMapping("/{paymentId}")
    public ResponseEntity<?> updatePayment(@PathVariable Integer paymentId, @RequestBody PaymentDTO paymentDTO) {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            if (authentication == null || !authentication.isAuthenticated()) {
                return ResponseEntity.status(401).body("User not authenticated");
            }

            Payment payment = paymentRepository.findById(paymentId)
                    .orElseThrow(() -> new Exception("Payment not found"));

            if (paymentDTO.getReceivedUser() != null) {
                payment.setReceivedUser(paymentDTO.getReceivedUser());
            }
            if (paymentDTO.getReceivedAddress() != null) {
                payment.setReceivedAddress(paymentDTO.getReceivedAddress());
            }
            if (paymentDTO.getPhoneNumber() != null) {
                payment.setPhoneNumber(paymentDTO.getPhoneNumber());
            }
            if (paymentDTO.getPaymentMethod() != null) {
                payment.setPaymentMethod(paymentDTO.getPaymentMethod());
            }

            Payment updatedPayment = paymentRepository.save(payment);
            return ResponseEntity.ok(updatedPayment);
        } catch (Exception e) {
            return ResponseEntity.status(400).body("Error updating payment: " + e.getMessage());
        }
    }

    @GetMapping("/{paymentId}")
    public ResponseEntity<?> getPayment(@PathVariable Integer paymentId) {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            if (authentication == null || !authentication.isAuthenticated()) {
                return ResponseEntity.status(401).body("User not authenticated");
            }

            Payment payment = paymentRepository.findById(paymentId)
                    .orElseThrow(() -> new Exception("Payment not found"));

            return ResponseEntity.ok(payment);
        } catch (Exception e) {
            return ResponseEntity.status(400).body("Error retrieving payment: " + e.getMessage());
        }
    }

    @DeleteMapping("/{paymentId}")
    public ResponseEntity<?> deletePayment(@PathVariable Integer paymentId) {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            if (authentication == null || !authentication.isAuthenticated()) {
                return ResponseEntity.status(401).body("User not authenticated");
            }

            Payment payment = paymentRepository.findById(paymentId)
                    .orElseThrow(() -> new Exception("Payment not found"));

            paymentRepository.delete(payment);
            return ResponseEntity.ok("Payment deleted successfully");
        } catch (Exception e) {
            return ResponseEntity.status(400).body("Error deleting payment: " + e.getMessage());
        }
    }
}
