import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import "./styles/global.css";
import "bootstrap/dist/css/bootstrap.min.css";
import Home from './pages/user/Home';
import Product from './pages/user/Product';
import Cart from './pages/user/Cart';
import Login from './pages/user/Login';
import Signup from './pages/user/Signup';
import Navbar from './components/Navbar'; 
import Dashboard from './pages/admin/Dashboard';
import ManageProducts from './pages/admin/ManageProducts';
import ManageOrders from './pages/admin/ManageOrders';
import ManageUsers from './pages/admin/ManageUsers';
import ProtectedRoute from './components/ProtectedRoute';
import AdminLayout from "./components/AdminLayout";
import Checkout from './pages/user/Checkout';
import OrderConfirmation from './pages/user/OrderConfirmation';


function App() {
  return (
    <>
      <Navbar />
      <Routes>
        {/* User Pages */}
        <Route path="/" element={<Home />} />
        <Route path="/product/:id" element={<Product />} />
        <Route path="/cart" element={<Cart />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/checkout" element={<Checkout />} /> 
        <Route path="/order-confirmation" element={<OrderConfirmation />} />

        {/* Admin Pages */}
        <Route path="/admin" element={<ProtectedRoute element={<AdminLayout />} />}>
          <Route path="/admin/dashboard" element={<ProtectedRoute element={<Dashboard />} />} />
          <Route path="/admin/manage-products" element={<ProtectedRoute element={<ManageProducts />} />} />
          <Route path="/admin/manage-orders" element={<ProtectedRoute element={<ManageOrders />} />} />
          <Route path="/admin/manage-users" element={<ProtectedRoute element={<ManageUsers />} />} />
        </Route>
      </Routes>
    </>
  );
}
export default App;
