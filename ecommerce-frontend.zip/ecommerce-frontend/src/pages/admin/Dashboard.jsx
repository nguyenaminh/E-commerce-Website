import React from 'react';
import { Link } from 'react-router-dom';
import '../../styles/admin/admin.css';

const Dashboard = () => {
    return (
        <div className="admin-container">
            <h1>Admin Dashboard</h1>
            <div className="admin-links">
                <Link to="/admin/products">Manage Products</Link>
                <Link to="/admin/orders">Manage Orders</Link>
                <Link to="/admin/users">Manage Users</Link>
            </div>
        </div>
    );
};

export default Dashboard;
