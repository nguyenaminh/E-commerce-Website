import React from 'react';
import '../../styles/admin/admin.css';

const ManageOrders = () => {
    const orders = [
        { id: 101, user: "John Doe", status: "Pending" },
        { id: 102, user: "Jane Smith", status: "Shipped" }
    ];

    return (
        <div className="admin-container">
            <h1>Manage Orders</h1>
            <table>
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>User</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    {orders.map(order => (
                        <tr key={order.id}>
                            <td>{order.id}</td>
                            <td>{order.user}</td>
                            <td>{order.status}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default ManageOrders;
