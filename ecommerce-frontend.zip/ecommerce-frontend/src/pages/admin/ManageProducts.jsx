import React, { useState } from 'react';
import '../../styles/admin/admin.css';

const ManageProducts = () => {
    const [products, setProducts] = useState([
        { id: 1, name: "Sunglasses A", price: 50 },
        { id: 2, name: "Sunglasses B", price: 70 }
    ]);

    const handleDelete = (id) => {
        setProducts(products.filter(product => product.id !== id));
    };

    return (
        <div className="admin-container">
            <h1>Manage Products</h1>
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Price</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {products.map(product => (
                        <tr key={product.id}>
                            <td>{product.name}</td>
                            <td>${product.price}</td>
                            <td>
                                <button className="delete-btn" onClick={() => handleDelete(product.id)}>Delete</button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default ManageProducts;
