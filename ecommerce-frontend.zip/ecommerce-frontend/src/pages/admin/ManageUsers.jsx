import React from 'react';
import '../../styles/admin/admin.css';

const ManageUsers = () => {
    const users = [
        { id: 1, name: "John Doe", email: "john@example.com" },
        { id: 2, name: "Jane Smith", email: "jane@example.com" }
    ];

    return (
        <div className="admin-container">
            <h1>Manage Users</h1>
            <ul>
                {users.map(user => (
                    <li key={user.id}>{user.name} - {user.email}</li>
                ))}
            </ul>
        </div>
    );
};

export default ManageUsers;
