import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import '../../styles/user/Login.css';

const Login = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const navigate = useNavigate();

    const handleLogin = (e) => {
        e.preventDefault();

        // Mock authentication logic
        const users = [
            { email: "admin@example.com", password: "admin123", role: "admin" },
            { email: "user@example.com", password: "user123", role: "user" },
        ];
      
        const user = users.find((u) => u.email === email && u.password === password);
      
        if (user) {
            localStorage.setItem("user", JSON.stringify(user)); // Save user data
            if (user.role === "admin") {
              navigate("/admin/dashboard"); // Redirect admin
            } else {
              navigate("/"); // Redirect normal user
            }
        } else {
            setError("Invalid email or password");
        }
    };

    return (
        <div className="login-container">
            <h2>Login</h2>
            <form onSubmit={handleLogin} className="login-form">
                <div className="form-group">
                    <label htmlFor="email">Email</label>
                    <input
                        type="email"
                        id="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="Enter your email"
                        required
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="password">Password</label>
                    <input
                        type="password"
                        id="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="Enter your password"
                        required
                    />
                </div>
                {error && <p className="error-message">{error}</p>}
                <button type="submit" className="login-button btn btn-sucess">Login</button>
            </form>
            <p className="signup-link">
                Don't have an account? <a href="/signup">Sign up</a>
            </p>
        </div>
    );
};

export default Login;