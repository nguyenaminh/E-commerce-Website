import React from "react";
import "../../styles/user/Home.css";

function Home() {
  const products = [
    { id: 1, name: "Product 1", price: "$10", description: "This is product 1." },
    { id: 2, name: "Product 2", price: "$20", description: "This is product 2." },
    { id: 3, name: "Product 3", price: "$30", description: "This is product 3." },
  ];

  return (
    <div className="home">
      <h1>Welcome to Our E-commerce Store!</h1>
      <div className="product-list">
        {products.map((product) => (
          <div key={product.id} className="product-card">
            <h2>{product.name}</h2>
            <p>{product.description}</p>
            <p><strong>{product.price}</strong></p>
            <button className="btn btn-sucess">Add to Cart</button>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Home;
