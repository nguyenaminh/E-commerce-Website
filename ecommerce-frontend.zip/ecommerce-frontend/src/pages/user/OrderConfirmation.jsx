import { Link } from "react-router-dom";
import { useLocation , useNavigate } from "react-router-dom";
import "../../styles/user/OrderConfirmation.css";

function OrderConfirmation() {
    const location = useLocation();
    const navigate = useNavigate();

    const orderDetails = location.state || {
        orderId : Math.floor(Math.random() * 10000),
        estimatedDelivery : "3-5 business days",
    };

    return (
        <div className="order-confirmation">
            <h1>Order Confirmed! Thank you for your purchase!</h1>
            <p>Your order ID: <strong>{orderDetails.orderId}</strong></p>
            <p>Estimated delivery: {orderDetails.estimatedDelivery}</p>
            
            <button onClick={() => navigate("/")} className="btn-primary btn btn-sucess">
            Return to Home
            </button>
        </div>
    );
}

export default OrderConfirmation;
