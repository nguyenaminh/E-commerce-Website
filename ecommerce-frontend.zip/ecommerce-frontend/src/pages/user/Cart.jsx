import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import '../../styles/user/Cart.css';

function Cart() {
  const [cartItems, setCartItems] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const savedCart = JSON.parse(localStorage.getItem('cart')) || [];
    setCartItems(savedCart);
  }, []);

  const handleUpdateQuantity = (itemId, newQuantity) => {
    const updatedCart = cartItems.map(item => 
      item.phoneId === itemId ? { ...item, quantity: Math.max(1, newQuantity) } : item
    );
    setCartItems(updatedCart);
    localStorage.setItem('cart', JSON.stringify(updatedCart));
  };

  const handleRemoveItem = (itemId) => {
    const filteredCart = cartItems.filter(item => item.phoneId !== itemId);
    setCartItems(filteredCart);
    localStorage.setItem('cart', JSON.stringify(filteredCart));
  };

  const calculateTotal = () => {
    return cartItems.reduce((total, item) => total + (item.price * item.quantity), 0);
  };

  return (
    <div className="cart-container container mt-4">
      <h1 className="text-center mb-4">Your Shopping Cart</h1>
      
      {cartItems.length === 0 ? (
        <div className="cart-empty text-center">
          <p className="text-muted">Your cart is empty</p>
          <button 
            className="btn btn-outline-secondary"
            onClick={() => navigate('/')}
          >
            Continue Shopping
          </button>
        </div>
      ) : (
        <>
          <div className="cart-items list-group">
            {cartItems.map(item => (
              <div key={item.phoneId} className="cart-item list-group-item">
                <div className="row align-items-center">
                  <div className="col-md-2">
                    <img 
                      src={item.image} 
                      alt={item.phoneName} 
                      className="img-fluid rounded"
                      style={{ maxHeight: '80px' }}
                    />
                  </div>
                  <div className="col-md-4">
                    <h5 className="mb-1">{item.phoneName}</h5>
                    <small className="text-muted">Brand: {item.brandName}</small>
                  </div>
                  <div className="col-md-3">
                    <div className="input-group">
                      <button 
                        className="btn btn-outline-secondary"
                        onClick={() => handleUpdateQuantity(item.phoneId, item.quantity - 1)}
                      >
                        -
                      </button>
                      <input
                        type="number"
                        className="form-control text-center"
                        value={item.quantity}
                        min="1"
                        onChange={(e) => handleUpdateQuantity(item.phoneId, parseInt(e.target.value))}
                      />
                      <button 
                        className="btn btn-outline-secondary"
                        onClick={() => handleUpdateQuantity(item.phoneId, item.quantity + 1)}
                      >
                        +
                      </button>
                    </div>
                  </div>
                  <div className="col-md-2 text-end">
                    <h5>${(item.price * item.quantity).toFixed(2)}</h5>
                  </div>
                  <div className="col-md-1 text-end">
                    <button 
                      className="btn btn-danger"
                      onClick={() => handleRemoveItem(item.phoneId)}
                    >
                      ×
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="cart-total mt-4 p-3 bg-light rounded">
            <div className="row">
              <div className="col-md-8">
                <h4 className="mb-0">Total</h4>
              </div>
              <div className="col-md-4 text-end">
                <h3 className="text-success">${calculateTotal().toFixed(2)}</h3>
              </div>
            </div>
          </div>

          <div className="text-end mt-4">
            <button 
              className="btn btn-success btn-lg"
              onClick={() => navigate('/checkout')}
              disabled={cartItems.length === 0}
            >
              Proceed to Checkout
            </button>
          </div>
        </>
      )}
    </div>
  );
}

export default Cart;