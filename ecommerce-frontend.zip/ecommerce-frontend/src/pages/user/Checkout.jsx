import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "../../styles/user/Checkout.css";

function Checkout() {
  const [formData, setFormData] = useState({
    name: "",
    address: "",
    city: "",
    postalCode: "",
  });

  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // Add order submission logic here (mock submission for now)
    alert("Order Submitted!");


    navigate("/order-confirmation");
  };

  return (
    <div className="checkout">
      <h1>Checkout</h1>

      <div className="checkout-details">
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="name">Name:</label>
            <input
              type="text"
              id="name"
              name="name"
              value={formData.name}
              onChange={handleChange}
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="address">Address:</label>
            <input
              type="text"
              id="address"
              name="address"
              value={formData.address}
              onChange={handleChange}
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="city">City:</label>
            <input
              type="text"
              id="city"
              name="city"
              value={formData.city}
              onChange={handleChange}
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="postalCode">Postal Code:</label>
            <input
              type="text"
              id="postalCode"
              name="postalCode"
              value={formData.postalCode}
              onChange={handleChange}
              required
            />
          </div>
          <button type="submit" className="btn-primary btn btn-success">
            Confirm Order
          </button>
        </form>
      </div>

      <div className="checkout-summary">
        <h3>Cart Summary</h3>
        {/* Here you would dynamically list items from cart */}
        <p>Item 1 - $10</p>
        <p>Item 2 - $20</p>
        <p>Total: $30</p>
      </div>
    </div>
  );
}

export default Checkout;
