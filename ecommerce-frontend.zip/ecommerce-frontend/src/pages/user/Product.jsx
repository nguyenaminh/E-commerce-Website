import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useState, useEffect } from 'react';


function Product() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [product, setProduct] = useState(null);
  const [quantity, setQuantity] = useState(1);
  const [brand, setBrand] = useState(null);
  const [category, setCategory] = useState(null);
  const [reviews, setReviews] = useState([]);
  const [newReview, setNewReview] = useState({
    rating: 5,
    comment: '',
  });

  const mockBrands = [
    { brandId: 1, brandName: 'Apple', description: 'Premium Smartphones' },
    { brandId: 2, brandName: 'Samsung', description: 'Innovative Electronics' },
    { brandId: 3, brandName: 'Sony', description: 'Entertainment and Technology' },    
  ];

  const mockCategories = [
    { categoryId: 1, categoryName: 'Smartphones', description: 'Latest Smartphones' },
    { categoryId: 2, categoryName: 'Accessories', description: 'Gadgets and Accessories' },    
  ];

  useState(() => {
    // Simulated API call to fetch product details
    const mockProduct = {
      phoneId: id,
      phoneName: `Phone Model ${id}`,
      price: 599.99,
      description: 'High-end smartphone with advanced features',
      image: 'placeholder-phone.jpg',
      createdAt: new Date().toISOString(),
      categoryId: 1,
      brandId: 1
    };

    const mockReviews = [
      {
        reviewId: 1,
        rating: 5,
        comment: 'Excellent phone!',
        createdAt: '2023-07-20',
        userId: 1,
        phoneId: id
      }
    ];

    setProduct(mockProduct);
    setBrand(mockBrands.find(b => b.brandId === mockProduct.brandId));
    setCategory(mockCategories.find(c => c.categoryId === mockProduct.categoryId));
    setReviews(mockReviews);
  }, [id]);

  const handleAddToCart = () => {
    const cartItem = {
      cartId: Date.now(),
      phoneId: product.phoneId,
      phoneName: product.phoneName,
      price: product.price,
      quantity: quantity,
      image: product.image,
      userId: 'tempUserId', // Replace with actual user ID from authentication context
    };

    const cart = JSON.parse(localStorage.getItem("cart")) || [];
    cart.push(cartItem);
    localStorage.setItem("cart", JSON.stringify(cart));

    navigate("/cart");
  };

  const handleReviewSubmit = (e) => {
    e.preventDefault();
    const review = {
      reviewId: Date.now(),
      rating: newReview.rating,
      comment: newReview.comment,
      createdAt: new Date().toISOString(),
      phoneId: id,
      userId: 'temp-user'
    };
    
    setReviews([...reviews, review]);
    setNewReview({ rating: 5, comment: '' });
  };

  if (!product) return <div className="loading">Loading product details</div>;

  return (
    <div className="product-page container mt-4">
      <div className="row">
        {/* Product Image */}
        <div className="col-md-6">
          <img 
            src={product.image} 
            alt={product.phoneName} 
            className="img-fluid rounded"
            style={{ maxHeight: '500px', objectFit: 'cover' }}
          />
        </div>

        {/* Product Details */}
        <div className="col-md-6">
          <h1 className="mb-3">{product.phoneName}</h1>
          <div className="d-flex justify-content-between align-items-center mb-3">
            <h2 className="text-primary">${product.price.toFixed(2)}</h2>
            {brand && <span className="badge bg-secondary">{brand.brandName}</span>}
          </div>
          
          {category && (
            <div className="mb-3">
              <h5>Category</h5>
              <p>{category.categoryName}</p>
            </div>
          )}

          <div className="mb-4">
            <h5>Description</h5>
            <p className="text-muted">{product.description}</p>
          </div>

          <div className="mb-4">
            <label className="form-label">Quantity:</label>
            <input
              type="number"
              className="form-control"
              style={{ width: '100px' }}
              min="1"
              value={quantity}
              onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value)))}
            />
          </div>

          <button 
            className="btn btn-primary btn-lg w-100"
            onClick={handleAddToCart}
          >
            Add to Cart
          </button>
        </div>
      </div>

      <div className="mt-5">
        <h3>Customer Reviews</h3>
        <form onSubmit={handleReviewSubmit} className="mb-4">
          <div className="mb-3">
            <label className="form-label">Rating:</label>
            <select
              className="form-select"
              value={newReview.rating}
              onChange={(e) => setNewReview({...newReview, rating: parseInt(e.target.value)})}
            >
              {[5,4,3,2,1].map(num => (
                <option key={num} value={num}>{num} Stars</option>
              ))}
            </select>
          </div>
          
          <div className="mb-3">
            <label className="form-label">Review:</label>
            <textarea
              className="form-control"
              rows="3"
              value={newReview.comment}
              onChange={(e) => setNewReview({...newReview, comment: e.target.value})}
            ></textarea>
          </div>
          
          <button type="submit" className="btn btn-outline-primary">
            Submit Review
          </button>
        </form>

        {reviews.map(review => (
          <div key={review.reviewId} className="card mb-3">
            <div className="card-body">
              <div className="d-flex justify-content-between align-items-center mb-2">
                <div className="text-warning">
                  {'★'.repeat(review.rating)}{'☆'.repeat(5 - review.rating)}
                </div>
                <small className="text-muted">
                  {new Date(review.createdAt).toLocaleDateString()}
                </small>
              </div>
              <p className="card-text">{review.comment}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Product;