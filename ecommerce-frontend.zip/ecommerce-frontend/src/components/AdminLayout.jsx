import { Link, Outlet, useNavigate } from "react-router-dom";
import "../styles/components/AdminLayout.css";

const AdminLayout = () => {
    const user = JSON.parse(localStorage.getItem("user"));

    if (!user || user.role !== "admin") {
        return <Navigate to="/login" replace />;
    }

    const handleLogout = () => {
        localStorage.removeItem("user");
        window.location.reload();
    };

    return (
        <div className="admin-container">
            <aside className="admin-sidebar">
                <h2>Admin Panel</h2>
                <ul>
                    <li><Link to="/admin/dashboard">Dashboard</Link></li>
                    <li><Link to="/admin/manage-products">Manage Products</Link></li>
                    <li><Link to="/admin/manage-orders">Manage Orders</Link></li>
                    <li><Link to="/admin/manage-users">Manage Users</Link></li>
                    <li><button onClick={handleLogout} className="logout-btn">Logout</button></li>
                </ul>
            </aside>

            <main className="admin-content">
                <Outlet />
            </main>
        </div>
    );
};

export default AdminLayout;
