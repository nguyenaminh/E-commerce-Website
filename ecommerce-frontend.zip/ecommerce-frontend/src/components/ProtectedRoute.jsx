import React, { use } from "react";
import { Navigate } from "react-router-dom";
import { useLocation } from "react-router-dom";

const ProtectedRoute = ({ element }) => {
  const location = useLocation();
  const user = JSON.parse(localStorage.getItem("user"));

  if (!user || !user.role) {
    return <Navigate to="/login" state={{ from: location }} replace />; // Redirect if not logged in
  }

  if (user.role !== "admin") {
    return <Navigate to="/" replace />; // Redirect if not admin
  }

  return element;
};

export default ProtectedRoute;
